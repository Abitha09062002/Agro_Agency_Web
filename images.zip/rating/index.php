

<?php
$title = 'Star Rating System';
$content = "inc/index_content.php";
include "layout/app.php";
?>
