<?php include "header.php"; ?>	
	<!-- Start All Pages -->
		
		<img src="images/cn.png" width="100%">
	<!-- End All Pages -->
	
	<!-- Start Contact -->
	<div>
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d250476.5709182037!2d77.38345487097895!3d11.210082292745081!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba96f87b6785d7f%3A0xb7302051277d875f!2sSri%20Balaji%20Mess%20and%20Bakery!5e0!3m2!1sen!2sin!4v1630861610895!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

	</div>
	<div class="contact-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Contact</h2>
						<p>Contact Information are Listed here Thanks for Visit Our Site</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<form id="contactForm">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<h1 style="font-family: cambria; color: red; text-align: center;">Sri Balaji Food Catering Service</h1>
									<div class="help-block with-errors"></div>
								</div>                                 
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Email Us :</b> dhina2425@gmail.com</span></center>
									<div class="help-block with-errors"></div>
								</div> 
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<center><span style="color: tomato; font-size: 1.2em; text-align: center; "><b><a href="tel:+91 6374610120">Contact:+91 6374610120</a></b></span></center>
									<div class="help-block with-errors"></div>
								</div> 
							</div>
							<div class="col-md-12">
								<div class="form-group"> 
									<center><span style="color: tomato; font-size: 1.3em; text-align: center; "><b>Location  :</b> 507, SKC Main Road ,Surampatti, Erode, Tamil Nadu, Pin - 638009</span></center>
									<div class="help-block with-errors"></div>
								</div>
								
							</div>
						</div>            
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- End Contact -->
<?php include "footer.php"; ?>