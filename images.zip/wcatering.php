<?php session_start(); ?>
<?php include  "header.php"; ?>

	<br>
    <br>
    <br>
    <br>
    <br>
    <br>
    
		<div class="container">
			
				
					<div class="inner-column">
					<h1>About<span>   Wedding Catering</span></h1>
						<p>

We are a Special Caterer for wedding. We have handled more than 500 wedding catering in Erode and all over south Tamil Nadu. Weddings are memorable events in a families history and food forms a main part of the wedding that will make guests remember the wedding for a long time. A good wedding lunch or dinner will make guests appreciate it for many many years. 

That’s why Wedding lunch or Dinner is given so much of importance in our culture. When a wedding is fixed the bride and grooms families first search for a venue and then a good caterer who would make the wedding a perfect one with their food.

We understand this concern of families and take utmost care and attention in carefully suggesting the menu based on a families culture and background and then making all arrangements in choosing the proper cooking utensils, cooking staffs and serving staff. We collaborate with the wedding family and design a menu to make their lunch/dinner a perfect one.

We are also priced reasonably making it affordable for all class of people. We have been the most preferred wedding caterers in Madurai for the level of quality we deliver in food. We cater many popular VIP families who have been engaging our catering services for many weddings in their homes.

Contact us to get a quote and see our menu options and how you can customize it to suite your guests</p>
		
					</div>
				
				<div class="col-lg-6 col-md-6">
					<img src="images/wcatering.jpg" style="height: 200px; width: 200%" class="img-fluid">
				</div>
				<div class="col-md-12">
					<div class="inner-pt">

					</div>
				
		
		</div>
	</div>
    <?php include "footer.php" ?>