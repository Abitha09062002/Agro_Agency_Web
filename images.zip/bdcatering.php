<?php session_start(); ?>
<?php include  "header.php"; ?>

	<br>
    <br>
    <br>
    <br>
    <br>
    <br>
    
		<div class="container">
			
				
					<div class="inner-column">
					<h1>Welcome To <span>Sri Balaji Food Catering Service</span></h1>
						<h4>Little Story</h4>
						<p>



						Birthday parties are a kids most precious moments in his/her life. We specialize in birthday catering understanding the needs that will excite kid guests and adults. Choosing menu that would be kid centric, we suggest dishes that every kid will relish on. You can pick a dish from our standard menu options or ask a specialized dish.

We have catered hundreds of birthday parties and personal family events like anniversaries, house warming ceremonies etc. We take extra concern and care for birthday parties so that kids will love the food without strong spicy tastes and not to spoil their stomach.

We can also arrange for party costumes, props, live cartoon characters etc to spice up the party. We have been recommended by guests who had attended our catered birthday events after experiencing our food designed for birthdays.

Contact us for a Birthday party catering quote.
</p>
		
					</div>
				
				<div class="col-lg-6 col-md-6">
					<img src="images/bdcatering.jpg" style="height: 200px; width: 200%" class="img-fluid">
				</div>
				<div class="col-md-12">
					<div class="inner-pt">

					</div>
				
		
		</div>
	</div>
    <?php include "footer.php" ?>