<?php session_start(); ?>
<?php include  "header.php"; ?>

	<br>
    <br>
    <br>
    <br>
    <br>
    <br>
    
		<div class="container">
			
				
					<div class="inner-column">
					<h1>About<span>Valaikappu</span></h1>
						
						<p>

Seemantham or valaikappu is a special event in an women’s motherhood and catering to this specific event needs lot of cultural understanding and expertise, which we properly possess and is our strength. Over the years we have been more popular for our seemantham / valaikappu catering services.

Valaikappu catering becomes so unique as the way food is presented and served is completely different from other event catering. Variety rices are served to give different kind of tastes. Coconut rice, sambar rice, sweet pongal, tamarind rice, lemon rice, kalkandu rice, curd rice etc form the main course supported with vegetable kootus.

Maintaining the unique tastes of the various rice varieties and making them distinct is what makes the catering service special. We understand the USP of this event and design menu accordingly and deliver food with high quality ingredients like ghee and cashews.

Contact us for a quote for your seematham/valaikappu event catering.
</p>
		
					</div>
				
				<div class="col-lg-6 col-md-6">
					<img src="images/valaikappu.jpg" style="height: 200px; width: 200%" class="img-fluid">
				</div>
				<div class="col-md-12">
					<div class="inner-pt">

					</div>
				
		
		</div>
	</div>
    <?php include "footer.php" ?>